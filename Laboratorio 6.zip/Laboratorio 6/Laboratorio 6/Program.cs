﻿// Veamos las siguientes maneras en que podemos gestionar las excepciones en c# (todos los ejemplos 
//partiendo desde la clase Program generada por default al crear un nuevo proyecto//