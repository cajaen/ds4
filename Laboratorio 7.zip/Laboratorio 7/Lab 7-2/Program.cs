﻿internal class Program
{
    private static void Main(string[] args)
    {
        JuegoDeDados j = new JuegoDeDados();
        j.Jugar();
    }
}