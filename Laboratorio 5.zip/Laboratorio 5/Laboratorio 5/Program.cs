﻿internal class Program
{
    private static void Main(string[] args)
    {
        int[] valores;
        valores = new int[100];
        valores = new int[20];
    }
}