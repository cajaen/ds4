﻿internal class Program
{
    private static void Main(string[] args)
    {
        string[] frutas = { "manzana", "platano", "naranja" };

        foreach (string frut in frutas)
            Console.WriteLine(frut);

    }
}